# AXL + UDGS Unified Product (Single System Object)

This package is a single synchronized workspace that integrates:

1) **AXL-UI** (repo root) — UI that interacts with GitHub API at runtime  
2) **AXL Engine** (`engine/`) — exoneural governor / artifact inventory  
3) **DAO-Arbiter SDK** (`tools/dao-arbiter/`) — deterministic loop engine + research PDF  
4) **E-legacy SDK** (`tools/E-legacy/`) — legacy variant (kept for audit parity)  
5) **UDGS Core** (`udgs_core/`) — minimal stdlib-only glue that builds a *single system object* with deterministic anchors

## Quick audit commands

```bash
# build SYSTEM_OBJECT.json + print system_anchor
python -m udgs_core.cli build-system-object --root . --config system/udgs.config.json --out SYSTEM_OBJECT.json

# validate STRICT_JSON packet
python -m udgs_core.cli validate-packet system/examples/packet.example.json || true

# compute deterministic anchor for any folder/file
python -m udgs_core.cli anchor engine
```

## Layout (high-level)

- `/` — AXL-UI
- `engine/` — AXL Engine
- `system/` — PROTOCOL_13/DEGC + unified config
- `udgs_core/` — system-object builder + strict packet validator + loop gate
- `tools/` — embedded SDKs (DAO-Arbiter + E-legacy)
- `sources/` — original input zips (audit)
