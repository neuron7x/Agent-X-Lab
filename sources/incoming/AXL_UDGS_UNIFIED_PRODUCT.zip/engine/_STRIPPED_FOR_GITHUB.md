# Stripped for GitHub

This snapshot is imported from `all-artifacts-as-is.zip` with virtual environments and caches removed.
