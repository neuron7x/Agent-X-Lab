# CHANGELOG — pr-orchestrator

## v1.0.0 — 2026-02-20
- RELEASE · Score 100/100 (target 98)
- IOPS-compliant IO-BUNDLE with deterministic eval harness
