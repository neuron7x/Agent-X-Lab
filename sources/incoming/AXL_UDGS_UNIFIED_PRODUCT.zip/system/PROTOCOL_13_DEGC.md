# PROTOCOL_13/DEGC — Deterministic External-Governed Convergence (fail-closed)

**Purpose:** convert LLM work from “conversation” into a deterministic, externally-verified engineering loop.  
**Truth source:** TRUTH_PLANE (CI/CD + logs + checks).  
**Termination authority:** CONTROL_PLANE (human governor only).  
**Failure mode:** fail-closed; any missing evidence or ambiguity ⇒ **HALT**.

## Planes (topology)

- **CONTROL_PLANE** — Human Governor (sole merge/terminate authority)
- **DATA_PLANE** — Executor agent (produces diffs, packets, scripts)
- **TRUTH_PLANE** — External oracle (CI/CD, unit tests, build, security gates)

## Canonical convergence cycle

`FAIL → FIX → PROVE → CHECKPOINT`  
Loop is restart-safe and entropy-controlled: each CHECKPOINT is an auditable snapshot.

## STRICT_JSON contract (single packet)

Top-level keys (no extras allowed):

- `FAIL_PACKET` (object) — external failure evidence (logs, failing checks, reproduction hints)
- `MUTATION_PLAN` (object) — minimal diffs plan; file-level targets; invariants
- `PRE_VERIFICATION_SCRIPT` (string) — deterministic local verification script
- `REGRESSION_TEST_PAYLOAD` (object) — regression suite definition + expected outcomes
- `SHA256_ANCHOR` (string) — SHA-256 anchor for audit

## Fail-closed invariants

1. **No silent failures:** all error states surface explicitly.
2. **No oracle → no truth:** CI/CD is the only truth contour for PASS/FAIL.
3. **Missing evidence ⇒ HALT.**
4. **Minimal diffs:** no dependency additions unless explicitly permitted.
5. **Type integrity:** do not weaken types or suppress checks.
6. **Polling invariants (AXL-UI):**
   - on GitHub rate limit reached ⇒ state becomes `RATE_LIMITED`
   - stop polling until reset moment
   - show countdown to reset
   - indicator animation only in `POLLING`

## Reference tooling (offline)

- Build SYSTEM_OBJECT anchor:
  - `python -m udgs_core.cli build-system-object --root . --config system/udgs.config.json --out SYSTEM_OBJECT.json`
- Validate STRICT_JSON packet:
  - `python -m udgs_core.cli validate-packet <packet.json>`
- Compute anchors:
  - `python -m udgs_core.cli anchor <path>`
- Evaluate fail-closed loop gate:
  - `python -m udgs_core.cli loop --evidence-json <evidence.json>`

