# AXL — Unified One-Project Workspace

This workspace bundles **AXL-UI (Lovable UI)** as the repository root and the **Agent‑X‑Lab Engine (system brain)** under `engine/`.
It preserves the project theme/goal/role: the UI remains a monochrome instrument-grade control interface that integrates with the engine via GitHub API at runtime.

## Layout
- `/` — **AXL-UI** (Lovable project; source of truth for the interface)
- `engine/` — **Agent‑X‑Lab Engine** (contracts, artifacts, VR.json, docs, Makefile, pyproject)
- `releases/` — frozen UI snapshot archives (v1.0 / v1.2 / v1.3)

## UI quick commands (from repo root)
```bash
npm ci --no-audit --no-fund
npm run test
npm run build
```

## Engine quick commands
```bash
cd engine
# follow engine README/Makefile; typical patterns:
# python -m pip install -e .
# make <target>
```

## Integration rule
The UI does **not** import engine code. It reads engine state through GitHub API (VR.json, artifacts/agent/*) at runtime.
