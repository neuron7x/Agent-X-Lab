from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Tuple


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str, *, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def sha256_json(obj: Dict[str, Any]) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(payload)


def iter_files(root: str) -> Iterable[str]:
    for dirpath, _, filenames in os.walk(root):
        for fn in sorted(filenames):
            yield os.path.join(dirpath, fn)


def sha256_tree(root: str) -> Tuple[str, Dict[str, str]]:
    """
    Deterministic directory hashing:
    - hashes each file
    - hashes the sorted mapping of relative paths -> file hash
    Returns: (tree_hash, file_hashes)
    """
    file_hashes: Dict[str, str] = {}
    root = os.path.abspath(root)
    for path in iter_files(root):
        rel = os.path.relpath(path, root).replace("\\", "/")
        file_hashes[rel] = sha256_file(path)

    tree_hash = sha256_json(file_hashes)
    return tree_hash, file_hashes
