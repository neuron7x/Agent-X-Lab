from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple


REQUIRED_KEYS = [
    "FAIL_PACKET",
    "MUTATION_PLAN",
    "PRE_VERIFICATION_SCRIPT",
    "REGRESSION_TEST_PAYLOAD",
    "SHA256_ANCHOR",
]


@dataclass
class ValidationError:
    path: str
    message: str


def _is_obj(x: Any) -> bool:
    return isinstance(x, dict)


def _is_str(x: Any) -> bool:
    return isinstance(x, str)


def validate_packet(obj: Dict[str, Any]) -> Tuple[bool, List[ValidationError]]:
    errors: List[ValidationError] = []

    if not _is_obj(obj):
        return False, [ValidationError("$", "Packet must be a JSON object")]

    for k in REQUIRED_KEYS:
        if k not in obj:
            errors.append(ValidationError(f"$.{k}", "Missing required key"))

    # type checks
    if "FAIL_PACKET" in obj and not _is_obj(obj["FAIL_PACKET"]):
        errors.append(ValidationError("$.FAIL_PACKET", "Must be an object"))
    if "MUTATION_PLAN" in obj and not _is_obj(obj["MUTATION_PLAN"]):
        errors.append(ValidationError("$.MUTATION_PLAN", "Must be an object"))
    if "PRE_VERIFICATION_SCRIPT" in obj and not _is_str(obj["PRE_VERIFICATION_SCRIPT"]):
        errors.append(ValidationError("$.PRE_VERIFICATION_SCRIPT", "Must be a string"))
    if "REGRESSION_TEST_PAYLOAD" in obj and not _is_obj(obj["REGRESSION_TEST_PAYLOAD"]):
        errors.append(ValidationError("$.REGRESSION_TEST_PAYLOAD", "Must be an object"))
    if "SHA256_ANCHOR" in obj and not _is_str(obj["SHA256_ANCHOR"]):
        errors.append(ValidationError("$.SHA256_ANCHOR", "Must be a string"))

    # STRICT_JSON: no extra top-level keys allowed (fail-closed)
    extra = [k for k in obj.keys() if k not in REQUIRED_KEYS]
    if extra:
        errors.append(ValidationError("$", f"Extra keys not allowed: {extra}"))

    return (len(errors) == 0), errors


def load_and_validate(path: str) -> Tuple[bool, Dict[str, Any], List[ValidationError]]:
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    ok, errs = validate_packet(obj)
    return ok, obj, errs
