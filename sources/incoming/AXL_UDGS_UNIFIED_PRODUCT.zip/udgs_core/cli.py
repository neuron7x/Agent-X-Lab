from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict

from .anchors import sha256_file, sha256_tree
from .state_machine import DeterministicCycle, Evidence
from .strict_json import load_and_validate
from .system_object import build_system_object, write_system_object


def cmd_anchor(args: argparse.Namespace) -> int:
    if os.path.isdir(args.path):
        tree_hash, _ = sha256_tree(args.path)
        print(tree_hash)
        return 0
    if os.path.isfile(args.path):
        print(sha256_file(args.path))
        return 0
    print(f"Path not found: {args.path}", file=sys.stderr)
    return 2


def cmd_validate_packet(args: argparse.Namespace) -> int:
    ok, _obj, errs = load_and_validate(args.packet)
    if ok:
        print("OK")
        return 0
    for e in errs:
        print(f"{e.path}: {e.message}", file=sys.stderr)
    return 1


def cmd_loop(args: argparse.Namespace) -> int:
    cycle = DeterministicCycle(fail_closed=True)
    evidence: Dict[str, Any] = {}

    if args.evidence_json:
        with open(args.evidence_json, "r", encoding="utf-8") as f:
            evidence = json.load(f)

    ev = Evidence(
        logs=evidence.get("logs"),
        hash_anchor=evidence.get("hash_anchor"),
        oracle_pass=evidence.get("oracle_pass"),
    )

    # step through to PROVE and evaluate, unless user wants single step
    steps = 1 if args.single_step else 3
    result = None
    for _ in range(steps):
        result = cycle.step(ev)

    assert result is not None
    out = {
        "next_state": result.next_state.value,
        "violated": [{"name": i.name, "rule": i.rule, "severity": i.severity} for i in result.violated],
        "notes": result.notes,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0 if out["next_state"] != "HALT" else 1


def cmd_build_system_object(args: argparse.Namespace) -> int:
    root = os.path.abspath(args.root)
    config_path = os.path.abspath(args.config)
    obj = build_system_object(root, config_path)
    write_system_object(args.out, obj)
    print(obj.system_anchor)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="udgs")
    sub = p.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("anchor", help="Compute SHA-256 anchor for file or directory")
    pa.add_argument("path")
    pa.set_defaults(fn=cmd_anchor)

    pv = sub.add_parser("validate-packet", help="Validate STRICT_JSON FAIL_PACKET bundle")
    pv.add_argument("packet")
    pv.set_defaults(fn=cmd_validate_packet)

    pl = sub.add_parser("loop", help="Run deterministic loop gates (fail-closed)")
    pl.add_argument("--evidence-json", default=None, help="JSON with keys: logs, hash_anchor, oracle_pass")
    pl.add_argument("--single-step", action="store_true")
    pl.set_defaults(fn=cmd_loop)

    ps = sub.add_parser("build-system-object", help="Build SYSTEM_OBJECT.json from config + file anchors")
    ps.add_argument("--root", default=".")
    ps.add_argument("--config", default="system/udgs.config.json")
    ps.add_argument("--out", default="SYSTEM_OBJECT.json")
    ps.set_defaults(fn=cmd_build_system_object)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
