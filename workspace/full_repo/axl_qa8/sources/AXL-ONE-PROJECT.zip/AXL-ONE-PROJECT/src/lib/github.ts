import type { GitHubSettings, VRData, Gate, GateStatus, EvidenceEntry, EvidenceEvent, PullRequest, ContractJson, ArsenalPrompt, ArsenalRole } from './types';

const API = 'https://api.github.com';

// ── Typed GitHub API response shapes ──

interface GitHubContentResponse {
  content: string;
  encoding: string;
  sha: string;
  name: string;
  path: string;
}

interface GitHubCheckRun {
  id: number;
  name: string;
  status: string;
  conclusion: string | null;
}

interface GitHubCheckRunsResponse {
  total_count: number;
  check_runs: GitHubCheckRun[];
}

interface GitHubJob {
  id: number;
  name: string;
  status: string;
  conclusion: string | null;
  started_at: string | null;
  completed_at: string | null;
}

interface GitHubJobsResponse {
  total_count: number;
  jobs: GitHubJob[];
}

interface GitHubWorkflowRun {
  id: number;
  name: string;
  display_title: string;
  path: string;
  status: string;
  conclusion: string | null;
  head_sha: string;
  created_at: string;
}

interface GitHubRunsResponse {
  total_count: number;
  workflow_runs: GitHubWorkflowRun[];
}

interface GitHubPR {
  number: number;
  title: string;
  html_url: string;
  head: { sha: string };
}

// ── ETag cache ──

const etagCache = new Map<string, { etag: string; data: unknown }>();

function headers(token: string, etag?: string): Record<string, string> {
  const h: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github.v3+json',
  };
  if (etag) h['If-None-Match'] = etag;
  return h;
}

function extractRateLimit(res: Response): void {
  const remaining = res.headers.get('X-RateLimit-Remaining');
  const reset = res.headers.get('X-RateLimit-Reset');
  // Rate-limit detection on BOTH ok and non-ok responses
  if (remaining === '0') {
    throw new Error(`RATE_LIMITED:${reset || ''}`);
  }
  if (res.status === 429) {
    throw new Error(`RATE_LIMITED:${reset || ''}`);
  }
}

// ── 5xx Retry with exponential backoff ──

const RETRY_DELAYS = [2000, 4000, 8000, 16000, 32000, 120000];

async function fetchWithRetry(url: string, init: RequestInit): Promise<Response> {
  let lastError: Error | null = null;
  // First attempt (no delay)
  for (let attempt = 0; attempt <= RETRY_DELAYS.length; attempt++) {
    if (attempt > 0) {
      await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt - 1]));
    }
    try {
      const res = await fetch(url, init);
      // 4xx: fail immediately (no retry)
      if (res.status >= 400 && res.status < 500) {
        return res;
      }
      // 5xx: retry
      if (res.status >= 500) {
        lastError = new Error(`SERVER_ERROR:${res.status}`);
        continue;
      }
      return res;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      if (attempt >= RETRY_DELAYS.length) break;
    }
  }
  throw lastError || new Error('FETCH_FAILED');
}

async function cachedFetch<T = unknown>(url: string, token: string): Promise<{ data: T; notModified: boolean }> {
  const cached = etagCache.get(url);
  const res = await fetchWithRetry(url, { headers: headers(token, cached?.etag) });

  extractRateLimit(res);

  if (res.status === 304 && cached) {
    return { data: cached.data as T, notModified: true };
  }

  if (!res.ok) throw new Error(`API_ERROR:${res.status}:${url}`);

  const data: T = await res.json();
  const etag = res.headers.get('ETag');
  if (etag) {
    etagCache.set(url, { etag, data });
  }
  return { data, notModified: false };
}

// ── Core API functions ──

export async function testConnection(settings: GitHubSettings): Promise<boolean> {
  const res = await fetchWithRetry(`${API}/repos/${settings.owner}/${settings.repo}`, {
    headers: headers(settings.token),
  });
  return res.ok;
}

export async function fetchRepoInfo(settings: GitHubSettings): Promise<unknown> {
  const { data } = await cachedFetch(`${API}/repos/${settings.owner}/${settings.repo}`, settings.token);
  return data;
}

export async function fetchContentsText(settings: GitHubSettings, path: string): Promise<string> {
  const { data } = await cachedFetch<GitHubContentResponse>(
    `${API}/repos/${settings.owner}/${settings.repo}/contents/${path}`,
    settings.token
  );
  const content = data.content;
  if (!content) throw new Error(`EMPTY_CONTENT:${path}`);
  return atob(content.replace(/\n/g, ''));
}

export async function fetchContentsJson<T = unknown>(settings: GitHubSettings, path: string): Promise<T> {
  const text = await fetchContentsText(settings, path);
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error(`PARSE_ERROR:${path}`);
  }
}

export async function fetchVRJson(settings: GitHubSettings): Promise<VRData> {
  return fetchContentsJson<VRData>(settings, 'VR.json');
}

export async function fetchContract(settings: GitHubSettings): Promise<ContractJson> {
  return fetchContentsJson<ContractJson>(settings, 'artifacts/agent/contract.json');
}

// ── Evidence parsing (pure, exported for testing) ──

export function parseEvidenceLines(text: string): { entries: EvidenceEntry[]; parseFailures: number } {
  const lines = text.split('\n').filter(l => l.trim());
  const entries: EvidenceEntry[] = [];
  let parseFailures = 0;

  for (const line of lines) {
    try {
      const evt: EvidenceEvent = JSON.parse(line);
      let status: GateStatus = 'ASSUMED';
      if (evt.status) {
        const s = evt.status.toUpperCase();
        if (s === 'PASS' || s === 'SUCCESS' || s === 'OK') status = 'PASS';
        else if (s === 'FAIL' || s === 'FAILURE' || s === 'ERROR') status = 'FAIL';
        else if (s === 'RUNNING') status = 'RUNNING';
        else if (s === 'PENDING') status = 'PENDING';
        else status = 'ASSUMED';
      } else if (evt.exit !== undefined) {
        status = evt.exit === 0 ? 'PASS' : 'FAIL';
      }

      entries.push({
        timestamp: evt.ts || evt.utc || '',
        type: evt.command || evt.id || '',
        status,
        sha: (evt.sha || '').slice(0, 8),
        path: evt.path || '',
      });
    } catch {
      parseFailures++;
    }
  }

  entries.reverse();
  return { entries: entries.slice(0, 30), parseFailures };
}

export async function fetchEvidenceJsonl(settings: GitHubSettings): Promise<{ entries: EvidenceEntry[]; parseFailures: number }> {
  const text = await fetchContentsText(settings, 'artifacts/agent/evidence.jsonl');
  return parseEvidenceLines(text);
}

export async function fetchActionRuns(settings: GitHubSettings, params?: { branch?: string; per_page?: number }): Promise<GitHubRunsResponse> {
  const pp = params?.per_page || 50;
  let url = `${API}/repos/${settings.owner}/${settings.repo}/actions/runs?per_page=${pp}`;
  if (params?.branch) url += `&branch=${encodeURIComponent(params.branch)}`;
  const { data } = await cachedFetch<GitHubRunsResponse>(url, settings.token);
  return data;
}

// ── Job cache ──

const jobCache = new Map<number, { jobs: GitHubJob[]; ts: number }>();
const JOB_CACHE_TTL = 60000;

export async function fetchRunJobs(settings: GitHubSettings, runId: number): Promise<GitHubJob[]> {
  const cached = jobCache.get(runId);
  if (cached && Date.now() - cached.ts < JOB_CACHE_TTL) {
    return cached.jobs;
  }
  const { data } = await cachedFetch<GitHubJobsResponse>(
    `${API}/repos/${settings.owner}/${settings.repo}/actions/runs/${runId}/jobs`,
    settings.token
  );
  const jobs = data.jobs || [];
  jobCache.set(runId, { jobs, ts: Date.now() });
  return jobs;
}

export function mapJobToGateStatus(job: GitHubJob | null): GateStatus {
  if (!job) return 'PENDING';
  const conclusion = job.conclusion;
  const status = job.status;
  if (conclusion === 'success') return 'PASS';
  if (conclusion === 'failure' || conclusion === 'cancelled' || conclusion === 'timed_out' || conclusion === 'action_required') return 'FAIL';
  if (status === 'in_progress' || status === 'queued') return 'RUNNING';
  return 'PENDING';
}

export function jobElapsed(job: GitHubJob | null): string {
  if (!job) return '—';
  if (job.completed_at && job.started_at) {
    const ms = new Date(job.completed_at).getTime() - new Date(job.started_at).getTime();
    const s = Math.round(ms / 1000);
    if (s >= 60) return `${Math.floor(s / 60)}m${String(s % 60).padStart(2, '0')}s`;
    return `${s}s`;
  }
  return '—';
}

// ── A-03: Parallel gate resolution ──

export async function resolveGatesFromContract(
  settings: GitHubSettings,
  contract: ContractJson,
  runs: GitHubWorkflowRun[]
): Promise<Gate[]> {
  // 1) Identify unique run_ids needed
  const runIdSet = new Set<number>();
  const checkToRun = new Map<string, GitHubWorkflowRun>();

  for (const check of contract.required_checks) {
    const workflowName = check.name.split('/')[0];
    const matchingRun = runs.find((r) => {
      const rName = r.name || r.display_title || '';
      const rPath = r.path || '';
      return rName.toLowerCase().includes(workflowName.toLowerCase()) ||
        rPath.toLowerCase().includes(workflowName.toLowerCase());
    });
    if (matchingRun) {
      runIdSet.add(matchingRun.id);
      checkToRun.set(check.name, matchingRun);
    }
  }

  // 2) Fetch all jobs in parallel (capped at 12 to prevent explosion)
  const runIds = Array.from(runIdSet).slice(0, 12);
  const jobResults = await Promise.allSettled(
    runIds.map(id => fetchRunJobs(settings, id))
  );

  const jobsByRunId = new Map<number, GitHubJob[]>();
  runIds.forEach((id, idx) => {
    const result = jobResults[idx];
    if (result.status === 'fulfilled') {
      jobsByRunId.set(id, result.value);
    }
  });

  // 3) Build gates
  const gates: Gate[] = [];
  for (const check of contract.required_checks) {
    const parts = check.name.split('/');
    const workflowName = parts[0];
    const jobName = parts.length > 1 ? parts.slice(1).join('/') : parts[0];

    const matchingRun = checkToRun.get(check.name);
    if (!matchingRun) {
      gates.push({ id: check.name, status: 'PENDING', tool: check.description || workflowName, elapsed: '—' });
      continue;
    }

    const jobs = jobsByRunId.get(matchingRun.id);
    if (!jobs) {
      gates.push({
        id: check.name, status: 'PENDING', tool: check.description || workflowName, elapsed: '—',
        log: `Failed to fetch jobs for run ${matchingRun.id}`,
      });
      continue;
    }

    const matchingJob = jobs.find((j) =>
      (j.name || '').toLowerCase().includes(jobName.toLowerCase())
    ) || jobs[0] || null;

    const gateStatus = mapJobToGateStatus(matchingJob);

    gates.push({
      id: check.name,
      status: gateStatus,
      tool: matchingJob?.name || jobName,
      elapsed: jobElapsed(matchingJob),
      log: matchingJob ? `[${matchingJob.name}]\nStatus: ${matchingJob.status}\nConclusion: ${matchingJob.conclusion || 'null'}\nStarted: ${matchingJob.started_at || '—'}\nCompleted: ${matchingJob.completed_at || '—'}` : undefined,
    });
  }

  return gates;
}

// ── A-01: Real PR check-runs with batched concurrency ──

const checkRunCache = new Map<string, { data: GitHubCheckRunsResponse; ts: number }>();
const CHECK_RUN_CACHE_TTL = 30000;

async function fetchCheckRuns(settings: GitHubSettings, sha: string): Promise<GitHubCheckRunsResponse> {
  const cached = checkRunCache.get(sha);
  if (cached && Date.now() - cached.ts < CHECK_RUN_CACHE_TTL) {
    return cached.data;
  }
  const { data } = await cachedFetch<GitHubCheckRunsResponse>(
    `${API}/repos/${settings.owner}/${settings.repo}/commits/${sha}/check-runs?per_page=100`,
    settings.token
  );
  checkRunCache.set(sha, { data, ts: Date.now() });
  return data;
}

// Simple batch queue: runs at most `concurrency` promises at a time
async function batchMap<T, R>(items: T[], concurrency: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let idx = 0;
  async function next(): Promise<void> {
    while (idx < items.length) {
      const i = idx++;
      results[i] = await fn(items[i]);
    }
  }
  const workers = Array.from({ length: Math.min(concurrency, items.length) }, () => next());
  await Promise.all(workers);
  return results;
}

export async function fetchPullRequests(settings: GitHubSettings): Promise<PullRequest[]> {
  const { data } = await cachedFetch<GitHubPR[]>(
    `${API}/repos/${settings.owner}/${settings.repo}/pulls?state=open&per_page=10`,
    settings.token
  );

  const prs: PullRequest[] = await batchMap(data, 4, async (pr) => {
    let checksTotal = 0;
    let checksPassed = 0;
    let checksFailed = 0;
    try {
      const crData = await fetchCheckRuns(settings, pr.head.sha);
      const runs = crData.check_runs || [];
      checksTotal = runs.length;
      checksPassed = runs.filter(cr => cr.status === 'completed' && cr.conclusion === 'success').length;
      checksFailed = runs.filter(cr =>
        cr.conclusion === 'failure' || cr.conclusion === 'cancelled' ||
        cr.conclusion === 'timed_out' || cr.conclusion === 'action_required'
      ).length;
    } catch {
      // If check-runs fail, leave as 0
    }
    return {
      number: pr.number,
      title: pr.title,
      checksTotal,
      checksPassed,
      checksFailed,
      url: pr.html_url,
    };
  });

  return prs;
}

export async function fetchManifest(settings: GitHubSettings): Promise<EvidenceEntry[]> {
  try {
    const text = await fetchContentsText(settings, 'MANIFEST.json');
    const manifest: Array<{ timestamp?: string; utc?: string; type?: string; name?: string; status?: string; sha?: string; hash?: string; path?: string }> = JSON.parse(text);
    if (Array.isArray(manifest)) {
      return manifest.map((e) => ({
        timestamp: e.timestamp || e.utc || '',
        type: e.type || e.name || '',
        status: (e.status || 'PASS') as GateStatus,
        sha: (e.sha || e.hash || '').slice(0, 8),
        path: e.path || '',
      }));
    }
  } catch { /* ignore */ }
  return [];
}

// ── Arsenal: fetch prompt objects from /objects/ ──

interface GitHubDirEntry {
  name: string;
  path: string;
  type: string;
  sha: string;
}

function detectArsenalRole(text: string): ArsenalRole {
  const lower = text.toLowerCase();
  if (/\b(pr|orchestrator|readiness)\b/.test(lower)) return 'PR-AGENT';
  if (/\b(security|appsec|supply.chain)\b/.test(lower)) return 'SECURITY-AGENT';
  if (/\b(ci|test|flake|reliability)\b/.test(lower)) return 'CI-AGENT';
  if (/\b(docs|quickstart|onboarding)\b/.test(lower)) return 'DOCS-AGENT';
  if (/\b(science|simulation|research)\b/.test(lower)) return 'SCIENCE-AGENT';
  return 'OTHER';
}

export function parseArsenalMeta(content: string, path: string, sha: string): ArsenalPrompt {
  const lines = content.split('\n');
  // Title: first line starting with # or first non-empty line
  const titleLine = lines.find(l => l.startsWith('#')) || lines.find(l => l.trim()) || path;
  const title = titleLine.replace(/^#+\s*/, '').trim();

  // Version
  const versionMatch = content.match(/Version:\s*(.+)/i);
  const version = versionMatch ? versionMatch[1].trim().split(/\s*[\|│]/)[0].trim() : '—';

  // Target
  const targetMatch = content.match(/Target:\s*(.+)/i);
  let target = 'Universal';
  if (targetMatch) {
    target = targetMatch[1].trim();
  } else {
    const cl = content.toLowerCase();
    if (cl.includes('codex') && cl.includes('claude')) target = 'Codex / Claude';
    else if (cl.includes('codex') && cl.includes('copilot')) target = 'Codex / GitHub Copilot';
    else if (cl.includes('codex')) target = 'Codex';
    else if (cl.includes('copilot')) target = 'GitHub Copilot';
    else if (cl.includes('claude')) target = 'Claude';
  }

  // Role
  const role = detectArsenalRole(title + ' ' + content.slice(0, 500));

  // ID
  const id = path.split('/').pop()?.replace(/\.(md|txt)$/, '') ?? sha.slice(0, 8);

  return { id, title, role, version, target, content, sha: sha.slice(0, 8), path };
}

export async function fetchArsenalIndex(settings: GitHubSettings): Promise<ArsenalPrompt[]> {
  const { data } = await cachedFetch<GitHubDirEntry[]>(
    `${API}/repos/${settings.owner}/${settings.repo}/contents/objects`,
    settings.token
  );

  const files = data.filter(
    (entry) => entry.type === 'file' && (entry.name.endsWith('.md') || entry.name.endsWith('.txt'))
  );

  const results = await Promise.allSettled(
    files.slice(0, 12).map(async (file) => {
      const content = await fetchContentsText(settings, file.path);
      return parseArsenalMeta(content, file.path, file.sha);
    })
  );

  const prompts = results
    .filter((r): r is PromiseFulfilledResult<ArsenalPrompt> => r.status === 'fulfilled')
    .map((r) => r.value);

  prompts.sort((a, b) => a.title.localeCompare(b.title));

  if (prompts.length === 0) {
    throw new Error('ARSENAL_EMPTY: No protocol files found in /objects/');
  }

  return prompts;
}
