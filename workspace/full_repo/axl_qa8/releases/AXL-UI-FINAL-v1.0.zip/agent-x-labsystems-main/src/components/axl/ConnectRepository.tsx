import { useState } from 'react';
import type { GitHubSettings } from '@/lib/types';
import { useLanguage } from '@/hooks/useLanguage';

interface ConnectRepositoryProps {
  onConnect: (settings: Partial<GitHubSettings>) => void;
  onPreviewDemo: () => void;
}

export function ConnectRepository({ onConnect, onPreviewDemo }: ConnectRepositoryProps) {
  const { t } = useLanguage();
  const [token, setToken] = useState('');
  const [owner, setOwner] = useState('neuron7x');
  const [repo, setRepo] = useState('Agent-X-Lab');

  const inputStyle: React.CSSProperties = {
    background: 'var(--bg-tertiary)',
    border: '1px solid var(--border-default)',
    color: 'var(--text-primary)',
    fontFamily: 'inherit',
    fontSize: 14,
    padding: '12px 16px',
    width: '100%',
    borderRadius: 12,
    outline: 'none',
    fontWeight: 400,
    transition: 'border-color 200ms ease-out',
    height: 48,
  };

  const canSubmit = token && owner;

  return (
    <div className="flex items-center justify-center" style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <div className="axl-panel" style={{ width: 400, padding: 'var(--space-2xl)', animation: 'stagger-reveal 300ms ease forwards' }}>
        <div className="text-center" style={{ marginBottom: 'var(--space-2xl)' }}>
          <div style={{ fontSize: 20, color: 'var(--text-primary)', fontWeight: 600, marginBottom: 'var(--space-sm)' }}>AGENT-X-LAB</div>
          <p style={{ fontSize: 14, color: 'var(--text-tertiary)', fontWeight: 400 }}>{t('connectToAgentXLab')}</p>
        </div>

        <div className="flex flex-col" style={{ gap: 'var(--space-md)', marginBottom: 'var(--space-xl)' }}>
          <label>
            <span className="block" style={{ fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 400, marginBottom: 'var(--space-xs)' }}>{t('token')}</span>
            <input type="password" value={token} onChange={e => setToken(e.target.value)} style={inputStyle} placeholder="ghp_..." onFocus={e => { e.currentTarget.style.borderColor = 'var(--text-primary)'; }} onBlur={e => { e.currentTarget.style.borderColor = 'var(--border-default)'; }} />
          </label>
          <label>
            <span className="block" style={{ fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 400, marginBottom: 'var(--space-xs)' }}>{t('owner')}</span>
            <input type="text" value={owner} onChange={e => setOwner(e.target.value)} style={inputStyle} placeholder="neuron7x" onFocus={e => { e.currentTarget.style.borderColor = 'var(--text-primary)'; }} onBlur={e => { e.currentTarget.style.borderColor = 'var(--border-default)'; }} />
          </label>
          <label>
            <span className="block" style={{ fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 400, marginBottom: 'var(--space-xs)' }}>{t('repository')}</span>
            <input type="text" value={repo} onChange={e => setRepo(e.target.value)} style={inputStyle} placeholder="Agent-X-Lab" onFocus={e => { e.currentTarget.style.borderColor = 'var(--text-primary)'; }} onBlur={e => { e.currentTarget.style.borderColor = 'var(--border-default)'; }} />
          </label>
        </div>

        <button
          onClick={() => onConnect({ token, owner, repo })}
          disabled={!canSubmit}
          className="axl-surface w-full"
          style={{ fontSize: 14, padding: '12px', fontWeight: 500, cursor: canSubmit ? 'pointer' : 'default', borderRadius: 999, marginBottom: 'var(--space-sm)', opacity: canSubmit ? 1 : 0.4 }}
        >
          {t('connect')}
        </button>

        <button
          onClick={onPreviewDemo}
          className="axl-surface w-full"
          style={{ fontSize: 12, padding: '10px', fontWeight: 400, cursor: 'pointer', borderRadius: 999 }}
        >
          {t('previewDemo')}
        </button>
      </div>
    </div>
  );
}
