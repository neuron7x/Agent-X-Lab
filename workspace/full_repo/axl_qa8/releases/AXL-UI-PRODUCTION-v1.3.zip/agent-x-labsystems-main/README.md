# AGENT-X-LAB — Control Interface v1.3

[![Tests](https://img.shields.io/badge/tests-48%20passed-brightgreen)]()
[![Build](https://img.shields.io/badge/build-EXIT%200-brightgreen)]()
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue)]()

Deterministic CI verification dashboard. Real-time monitoring of GitHub repositories via ARA (Assess-Remediate-Assert) methodology.

## Stack
- React 18 + TypeScript strict
- Vite 5 + SWC + code splitting
- TanStack Query v5
- JetBrains Mono design system

## Architecture
```
src/
├── components/axl/     # AXL UI components
├── hooks/              # useGitHubAPI, useArsenal, useCountUp, useScramble
├── lib/                # github.ts, i18n.ts, types.ts, mockData.ts
├── pages/Index.tsx     # Lazy-loaded screens
└── test/               # 48 unit tests
```

## Protocol Gates (G0–G10)
All gates verified via VR.json SSOT. ASSUMED_SINGLE_RUN = always RED.

## Deploy
```bash
npm install && npm run build
# dist/ → Vercel / Netlify / Nginx
```

## Features
- Rate-limit detection + live countdown
- Progressive disclosure Arsenal (IO-Bundle v1.0)
- Dot grid background + circle pulse animations
- Full i18n UA/EN with JetBrains Mono
- prefers-reduced-motion support
- CSP security headers
