import React from 'react';

interface SkeletonPanelProps {
  variant?: 'default' | 'home' | 'pipeline' | 'evidence' | 'arsenal';
}

const pulse: React.CSSProperties = {
  background: 'linear-gradient(90deg, #111 25%, #1a1a1a 50%, #111 75%)',
  backgroundSize: '200% 100%',
  animation: 'skeleton-shimmer 1.4s ease-in-out infinite',
  borderRadius: 2,
};

const line = (w: string, h = 8, mb = 12): React.CSSProperties => ({
  ...pulse, width: w, height: h, marginBottom: mb,
});

export function SkeletonPanel({ variant = 'default' }: SkeletonPanelProps) {
  if (variant === 'home') return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '70vh', gap: 48 }}>
      <div style={{ ...pulse, width: 200, height: 200, borderRadius: '50%' }} />
      <div style={{ display: 'flex', gap: 48 }}>
        {[80, 60, 80].map((w, i) => <div key={i} style={line(`${w}px`, 24)} />)}
      </div>
    </div>
  );

  if (variant === 'pipeline') return (
    <div style={{ padding: 24 }}>
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} style={{ display: 'flex', gap: 12, marginBottom: 12, alignItems: 'center' }}>
          <div style={line('24px', 24)} />
          <div style={line('40%', 10)} />
          <div style={{ ...line('60px', 10), marginLeft: 'auto' }} />
        </div>
      ))}
    </div>
  );

  if (variant === 'evidence') return (
    <div style={{ padding: 24 }}>
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} style={{ marginBottom: 16, padding: '12px 0', borderBottom: '1px solid #111' }}>
          <div style={line('30%', 8, 8)} />
          <div style={line('70%', 8)} />
        </div>
      ))}
    </div>
  );

  if (variant === 'arsenal') return (
    <div style={{ display: 'flex', gap: 16, padding: 24 }}>
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} style={{ ...pulse, flex: '0 0 160px', height: 120, borderRadius: 4 }} />
      ))}
    </div>
  );

  return (
    <div style={{ padding: 24 }}>
      {[80, 60, 90, 40, 70].map((w, i) => (
        <div key={i} style={line(`${w}%`)} />
      ))}
    </div>
  );
}
