import { useState, useCallback } from 'react';
import type { GitHubSettings } from '@/lib/types';

const STORAGE_KEY = 'axl-github-settings';
const TOKEN_KEY   = 'axl-github-token';

const DEFAULT_SETTINGS: GitHubSettings = {
  token: '',
  owner: 'neuron7x',
  repo: 'Agent-X-Lab',
  pollInterval: 30,
};

// Basic obfuscation — NOT encryption, just prevents casual inspection
const obfuscate   = (s: string): string => btoa(s);
const deobfuscate = (s: string): string => { try { return atob(s); } catch { return ''; } };

function load(): GitHubSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const rawToken = localStorage.getItem(TOKEN_KEY);
    const base = raw ? JSON.parse(raw) : {};
    const token = rawToken ? deobfuscate(rawToken) : (base.token || '');
    return { ...DEFAULT_SETTINGS, ...base, token };
  } catch { /* ignore */ }
  return DEFAULT_SETTINGS;
}

export function useGitHubSettings() {
  const [settings, setSettings] = useState<GitHubSettings>(load);

  const updateSettings = useCallback((patch: Partial<GitHubSettings>) => {
    setSettings(prev => {
      const next = { ...prev, ...patch };
      // Store token separately, obfuscated
      const { token, ...rest } = next;
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...rest, token: '' }));
      if (token) localStorage.setItem(TOKEN_KEY, obfuscate(token));
      return next;
    });
  }, []);

  const clearSettings = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_KEY);
    setSettings(DEFAULT_SETTINGS);
  }, []);

  const isConfigured = Boolean(settings.token && settings.owner);

  return { settings, updateSettings, clearSettings, isConfigured };
}
