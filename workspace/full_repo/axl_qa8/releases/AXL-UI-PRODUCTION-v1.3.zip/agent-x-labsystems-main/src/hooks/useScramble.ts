import { useState, useEffect, useRef } from 'react';

const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

export function useScramble(text: string, duration = 400): string {
  const [display, setDisplay] = useState(text);
  const prevText = useRef(text);

  useEffect(() => {
    if (text === prevText.current) return;
    prevText.current = text;
    const frames = Math.floor(duration / 40);
    let frame = 0;

    const interval = setInterval(() => {
      frame++;
      const progress = frame / frames;
      const resolved = Math.floor(progress * text.length);
      const scrambled = text
        .split('')
        .map((char, i) => {
          if (i < resolved) return char;
          if (char === ' ') return ' ';
          return CHARS[Math.floor(Math.random() * CHARS.length)];
        })
        .join('');
      setDisplay(scrambled);
      if (frame >= frames) {
        clearInterval(interval);
        setDisplay(text);
      }
    }, 40);

    return () => clearInterval(interval);
  }, [text, duration]);

  return display;
}
