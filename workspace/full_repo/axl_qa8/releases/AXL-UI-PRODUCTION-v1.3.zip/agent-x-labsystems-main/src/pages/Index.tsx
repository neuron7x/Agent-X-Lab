import React, { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { useGitHubSettings } from '@/hooks/useGitHubSettings';
import { useGitHubAPI } from '@/hooks/useGitHubAPI';
import { useArsenal } from '@/hooks/useArsenal';
import { TopBar } from '@/components/axl/TopBar';
import { TabBar } from '@/components/axl/TabBar';
import type { Tab } from '@/components/axl/TabBar';
import { ConnectRepository } from '@/components/axl/ConnectRepository';
import { ErrorBanner } from '@/components/axl/ErrorBanner';
import { ErrorBoundary } from '@/components/axl/ErrorBoundary';
import { SkeletonPanel } from '@/components/axl/SkeletonPanel';
import { BottomBar } from '@/components/axl/BottomBar';

// Lazy loading всіх screens — code splitting
const HomeScreen     = lazy(() => import('@/components/axl/HomeScreen').then(m => ({ default: m.HomeScreen })));
const PipelineScreen = lazy(() => import('@/components/axl/PipelineScreen').then(m => ({ default: m.PipelineScreen })));
const EvidenceScreen = lazy(() => import('@/components/axl/EvidenceScreen').then(m => ({ default: m.EvidenceScreen })));
const SettingsScreen = lazy(() => import('@/components/axl/SettingsScreen').then(m => ({ default: m.SettingsScreen })));
const ArsenalScreen  = lazy(() => import('@/components/axl/ArsenalScreen').then(m => ({ default: m.ArsenalScreen })));

const Index = () => {
  const [isDemoMode, setIsDemoMode] = useState<boolean>(
    () => sessionStorage.getItem('axl_demo_mode') === '1'
  );
  const [activeTab, setActiveTab] = useState<Tab>('status');

  useEffect(() => {
    sessionStorage.setItem('axl_demo_mode', isDemoMode ? '1' : '0');
  }, [isDemoMode]);

  const { settings, updateSettings, clearSettings, isConfigured } = useGitHubSettings();

  const {
    vrData, gates, evidence, prs,
    connectionStatus, error, rateLimitReset,
    contractError, parseFailures, isLoading, refetch,
  } = useGitHubAPI(settings, isConfigured, isDemoMode);

  const arsenal = useArsenal(settings, isConfigured, isDemoMode);

  const handlePreviewDemo = useCallback(() => setIsDemoMode(true), []);
  const handleExitDemo    = useCallback(() => { setIsDemoMode(false); clearSettings(); }, [clearSettings]);
  const handleConnect     = useCallback((token: string, owner: string, repo: string) => {
    updateSettings({ token, owner, repo, pollInterval: 30 });
  }, [updateSettings]);
  const handleUpdateSettings = useCallback((s: Parameters<typeof updateSettings>[0]) => {
    updateSettings(s);
  }, [updateSettings]);

  const showConnect = !isDemoMode && !isConfigured;

  const tabContent = () => {
    if (showConnect) return null;
    switch (activeTab) {
      case 'status':
        return (
          <ErrorBoundary panelName="HomeScreen">
            <Suspense fallback={<SkeletonPanel />}>
              <HomeScreen
                vrData={vrData}
                gates={gates}
                onViewPipeline={() => setActiveTab('pipeline')}
                onNavigateToArsenal={() => setActiveTab('arsenal')}
                contractError={contractError}
              />
            </Suspense>
          </ErrorBoundary>
        );
      case 'pipeline':
        return (
          <ErrorBoundary panelName="Pipeline">
            <Suspense fallback={<SkeletonPanel />}>
              <PipelineScreen vrData={vrData} gates={gates} isLoading={isLoading} />
            </Suspense>
          </ErrorBoundary>
        );
      case 'evidence':
        return (
          <ErrorBoundary panelName="Evidence">
            <Suspense fallback={<SkeletonPanel />}>
              <EvidenceScreen evidence={evidence} prs={prs} parseFailures={parseFailures} isLoading={isLoading} />
            </Suspense>
          </ErrorBoundary>
        );
      case 'arsenal':
        return (
          <ErrorBoundary panelName="Arsenal">
            <Suspense fallback={<SkeletonPanel />}>
              <ArsenalScreen prompts={arsenal.prompts} isLoading={arsenal.isLoading} />
            </Suspense>
          </ErrorBoundary>
        );
      case 'settings':
        return (
          <ErrorBoundary panelName="Settings">
            <Suspense fallback={<SkeletonPanel />}>
              <SettingsScreen
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onDisconnect={handleExitDemo}
                isDemoMode={isDemoMode}
                onExitDemo={handleExitDemo}
                connectionStatus={connectionStatus}
                onTestConnection={refetch}
              />
            </Suspense>
          </ErrorBoundary>
        );
      default:
        return null;
    }
  };

  return (
    <div className="app-root" style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column' }}>
      <TopBar
        repoName={settings.repo || 'Agent-X-Lab'}
        connectionStatus={isDemoMode ? 'DISCONNECTED' : connectionStatus}
        demoMode={isDemoMode}
        onSettingsClick={() => setActiveTab('settings')}
        rateLimitReset={rateLimitReset}
      />

      {!showConnect && (
        <ErrorBanner
          connectionStatus={connectionStatus}
          error={error}
          rateLimitReset={rateLimitReset}
          contractError={contractError}
          demoMode={isDemoMode}
        />
      )}

      <main style={{ flex: 1, overflowY: 'auto', paddingBottom: 88 }}>
        {showConnect ? (
          <ConnectRepository
            onConnect={handleConnect}
            onPreviewDemo={handlePreviewDemo}
            settings={settings}
          />
        ) : (
          <div key={activeTab} className="tab-content" style={{ animation: 'tab-enter 180ms ease-out' }}>
            {tabContent()}
          </div>
        )}
      </main>

      {!showConnect && (
        <>
          <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
          <BottomBar gates={gates} vrData={vrData} iteration={3} sha={vrData?.work_id?.slice(0, 7) || '—'} utc={vrData?.utc || '—'} />
        </>
      )}
    </div>
  );
};

export default Index;
