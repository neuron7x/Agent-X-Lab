import { describe, it, expect } from 'vitest';
import { mapJobToGateStatus, jobElapsed, parseEvidenceLines, parseArsenalMeta } from '@/lib/github';
import { derivePhase } from '@/components/axl/BottomBar';
import { formatCountdown } from '@/components/axl/TopBar';
import { translations } from '@/lib/i18n';
import type { Gate, VRData } from '@/lib/types';

// ── mapJobToGateStatus ──────────────────────────────────────
describe('mapJobToGateStatus', () => {
  const j = (status: string, conclusion: string | null) => ({ name: 'x', status, conclusion, started_at: null, completed_at: null });
  it('PASS for success', () => expect(mapJobToGateStatus(j('completed','success'))).toBe('PASS'));
  it('FAIL for failure', () => expect(mapJobToGateStatus(j('completed','failure'))).toBe('FAIL'));
  it('FAIL for cancelled', () => expect(mapJobToGateStatus(j('completed','cancelled'))).toBe('FAIL'));
  it('FAIL for timed_out', () => expect(mapJobToGateStatus(j('completed','timed_out'))).toBe('FAIL'));
  it('FAIL for action_required', () => expect(mapJobToGateStatus(j('completed','action_required'))).toBe('FAIL'));
  it('RUNNING for in_progress', () => expect(mapJobToGateStatus(j('in_progress',null))).toBe('RUNNING'));
  it('RUNNING for queued', () => expect(mapJobToGateStatus(j('queued',null))).toBe('RUNNING'));
  it('PENDING for null job', () => expect(mapJobToGateStatus(null)).toBe('PENDING'));
  it('PENDING for skipped', () => expect(mapJobToGateStatus(j('completed','skipped'))).toBe('PENDING'));
});

// ── jobElapsed ──────────────────────────────────────────────
describe('jobElapsed', () => {
  const j = (s: string|null, e: string|null) => ({ name: 'x', status: 'completed', conclusion: 'success', started_at: s, completed_at: e });
  it('returns dash for null job', () => expect(jobElapsed(null)).toBe('—'));
  it('returns dash when times null', () => expect(jobElapsed(j(null,null))).toBe('—'));
  it('formats 45s', () => expect(jobElapsed(j('2026-01-01T00:00:00Z','2026-01-01T00:00:45Z'))).toBe('45s'));
  it('formats 2m05s', () => expect(jobElapsed(j('2026-01-01T00:00:00Z','2026-01-01T00:02:05Z'))).toBe('2m05s'));
  it('formats 1m00s', () => expect(jobElapsed(j('2026-01-01T00:00:00Z','2026-01-01T00:01:00Z'))).toBe('1m00s'));
});

// ── parseEvidenceLines ─────────────────────────────────────
describe('parseEvidenceLines', () => {
  it('parses valid JSONL', () => {
    const r = parseEvidenceLines('{"ts":"2026-01-01T00:00:00Z","id":"a","exit":0}\n{"ts":"2026-01-01T00:00:01Z","id":"b","exit":0}');
    expect(r.entries.length).toBe(2);
    expect(r.parseFailures).toBe(0);
  });
  it('ignores empty lines', () => {
    const r = parseEvidenceLines('{"ts":"2026-01-01T00:00:00Z","id":"a","exit":0}\n\n\n');
    expect(r.entries.length).toBe(1);
  });
  it('counts malformed as parseFailures', () => {
    const r = parseEvidenceLines('{"ts":"2026-01-01T00:00:00Z","id":"a","exit":0}\nBAD\n{broken}');
    expect(r.parseFailures).toBe(2);
  });
  it('limits to 30 entries', () => {
    const lines = Array.from({length:40},(_,i)=>`{"ts":"2026-01-01T00:00:00Z","id":"e${i}","exit":0}`).join('\n');
    expect(parseEvidenceLines(lines).entries.length).toBeLessThanOrEqual(30);
  });
  it('exit=0 → PASS, exit!=0 → FAIL', () => {
    const r = parseEvidenceLines('{"ts":"2026-01-01T00:00:00Z","id":"ok","exit":0}\n{"ts":"2026-01-01T00:00:01Z","id":"fail","exit":1}');
    // entries are newest-first after reverse()
    expect(r.entries[0].status).toBe('FAIL');
    expect(r.entries[1].status).toBe('PASS');
  });
  it('missing exit → ASSUMED', () => {
    const r = parseEvidenceLines('{"ts":"2026-01-01T00:00:00Z","id":"u"}');
    expect(r.entries[0].status).toBe('ASSUMED');
  });
});

// ── i18n completeness ──────────────────────────────────────
describe('i18n completeness', () => {
  it('every key has ua and en strings', () => {
    for (const [, val] of Object.entries(translations)) {
      expect(val).toHaveProperty('ua');
      expect(val).toHaveProperty('en');
      expect((val.ua as string).length).toBeGreaterThan(0);
      expect((val.en as string).length).toBeGreaterThan(0);
    }
  });
  it('protocol-exact UA strings', () => {
    expect(translations.connLive.ua).toBe('ПІДКЛЮЧЕНО');
    expect(translations.connOffline.ua).toBe('ВІДКЛЮЧЕНО');
    expect(translations.connPolling.ua).toBe('ОПИТУВАННЯ');
    expect(translations.connError.ua).toBe('ПОМИЛКА');
    expect(translations.connRateLimited.ua).toBe('ЛІМІТ');
  });
});

// ── derivePhase ─────────────────────────────────────────────
describe('derivePhase', () => {
  const g = (status: string): Gate => ({ id: 'g', status: status as Gate['status'], tool: 't', elapsed: '1s' });
  const vr = (status: string, blockers: unknown[] = []): VRData => ({ status, blockers, utc: '', work_id: '', metrics: {} });
  it('0=OBSERVE when PENDING gates', () => expect(derivePhase([g('PENDING')], null)).toBe(0));
  it('1=SPECIFY when RUNNING gates', () => expect(derivePhase([g('RUNNING')], null)).toBe(1));
  it('2=EXECUTE when resolved but not RUN', () => expect(derivePhase([g('PASS'),g('FAIL')], vr('FAIL'))).toBe(2));
  it('3=PROVE when VR=RUN and 0 blockers', () => expect(derivePhase([g('PASS')], vr('RUN',[]))).toBe(3));
  it('2=EXECUTE when RUN but has blockers', () => expect(derivePhase([g('PASS')], vr('RUN',['b']))).toBe(2));
  it('0 when no gates', () => expect(derivePhase([], null)).toBe(0));
});

// ── formatCountdown ─────────────────────────────────────────
describe('formatCountdown', () => {
  it('00:00 for 0', () => expect(formatCountdown(0)).toBe('00:00'));
  it('00:00 for negative', () => expect(formatCountdown(-5)).toBe('00:00'));
  it('01:30 for 90s', () => expect(formatCountdown(90)).toBe('01:30'));
  it('01:05 for 65s', () => expect(formatCountdown(65)).toBe('01:05'));
  it('hh:mm:ss for 3661s', () => expect(formatCountdown(3661)).toBe('01:01:01'));
  it('59:59 for 3599s', () => expect(formatCountdown(3599)).toBe('59:59'));
});

// ── parseArsenalMeta ────────────────────────────────────────
describe('parseArsenalMeta', () => {
  it('extracts PR-AGENT role', () => {
    const r = parseArsenalMeta('# PR ORCHESTRATOR\nVersion: 2.0.0\n\nContent.', 'objects/t.txt', 'abc12345');
    expect(r.role).toBe('PR-AGENT');
  });
  it('extracts version', () => {
    const r = parseArsenalMeta('# Agent\nVersion: PR-TEST-2026.02.1\n\nContent.', 'objects/t.txt', 'abc12345');
    expect(r.version).toBe('PR-TEST-2026.02.1');
  });
  it('OTHER role for unknown content', () => {
    const r = parseArsenalMeta('# Generic\nSome random content.', 'objects/t.txt', 'abc12345');
    expect(r.role).toBe('OTHER');
  });
  it('uses sha param', () => {
    const r = parseArsenalMeta('# Test\n', 'objects/t.txt', 'deadbeef');
    expect(r.sha).toBe('deadbeef');
  });
  it('uses filename as id', () => {
    const r = parseArsenalMeta('# Test\n', 'objects/my-agent.txt', 'abc12345');
    expect(r.id).toBe('my-agent');
  });
});
