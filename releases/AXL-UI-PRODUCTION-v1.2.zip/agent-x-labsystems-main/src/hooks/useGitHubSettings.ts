import { useState, useCallback } from 'react';
import type { GitHubSettings } from '@/lib/types';

const STORAGE_KEY = 'axl-github-settings';

const DEFAULT_SETTINGS: GitHubSettings = {
  token: '',
  owner: 'neuron7x',
  repo: 'Agent-X-Lab',
  pollInterval: 30,
};

function load(): GitHubSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_SETTINGS;
}

export function useGitHubSettings() {
  const [settings, setSettings] = useState<GitHubSettings>(load);

  const updateSettings = useCallback((patch: Partial<GitHubSettings>) => {
    setSettings(prev => {
      const next = { ...prev, ...patch };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const clearSettings = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setSettings(DEFAULT_SETTINGS);
  }, []);

  const isConfigured = Boolean(settings.token && settings.owner);

  return { settings, updateSettings, clearSettings, isConfigured };
}
