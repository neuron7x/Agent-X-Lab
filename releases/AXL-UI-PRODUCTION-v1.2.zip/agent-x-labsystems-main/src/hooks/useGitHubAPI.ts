import React from 'react';
import { useQuery } from '@tanstack/react-query';
import type { GitHubSettings, AXLState, Gate, EvidenceEntry, ContractJson } from '@/lib/types';
import {
  fetchVRJson,
  fetchContract,
  fetchEvidenceJsonl,
  fetchPullRequests,
  fetchActionRuns,
  resolveGatesFromContract,
} from '@/lib/github';
import { MOCK_VR, MOCK_GATES, MOCK_EVIDENCE, MOCK_PRS } from '@/lib/mockData';

export function useGitHubAPI(settings: GitHubSettings, isConfigured: boolean, demoMode: boolean) {
  const pollMs = settings.pollInterval * 1000;
  const [storedRateLimitReset, setStoredRateLimitReset] = React.useState<number | null>(null);
  const isRateLimitedActive = storedRateLimitReset !== null && Date.now() / 1000 < storedRateLimitReset;
  const canFetch = isConfigured && !demoMode && !isRateLimitedActive;

  // VR.json
  const vrQuery = useQuery({
    queryKey: ['vr', settings.owner, settings.repo],
    queryFn: () => fetchVRJson(settings),
    enabled: canFetch,
    refetchInterval: canFetch ? pollMs : false,
    retry: 1,
  });

  // contract.json
  const contractQuery = useQuery({
    queryKey: ['contract', settings.owner, settings.repo],
    queryFn: () => fetchContract(settings),
    enabled: canFetch,
    refetchInterval: canFetch ? pollMs * 2 : false,
    retry: 1,
  });

  // evidence.jsonl
  const evidenceQuery = useQuery({
    queryKey: ['evidence-jsonl', settings.owner, settings.repo],
    queryFn: () => fetchEvidenceJsonl(settings),
    enabled: canFetch,
    refetchInterval: canFetch ? pollMs : false,
    retry: 1,
  });

  // workflow runs
  const runsQuery = useQuery({
    queryKey: ['runs', settings.owner, settings.repo],
    queryFn: () => fetchActionRuns(settings, { branch: 'main', per_page: 50 }),
    enabled: canFetch,
    refetchInterval: canFetch ? pollMs : false,
    retry: 1,
  });

  // Resolve gates from contract + runs
  const contract = contractQuery.data as ContractJson | undefined;
  const runs = runsQuery.data?.workflow_runs;

  const gatesQuery = useQuery({
    queryKey: ['gates-resolved', settings.owner, settings.repo, contract?.required_checks?.length, runs?.length],
    queryFn: () => resolveGatesFromContract(settings, contract!, runs!),
    enabled: canFetch && !!contract && !!runs && runs.length > 0,
    staleTime: pollMs,
    retry: 1,
  });

  // PRs
  const prsQuery = useQuery({
    queryKey: ['prs', settings.owner, settings.repo],
    queryFn: () => fetchPullRequests(settings),
    enabled: canFetch,
    refetchInterval: canFetch ? pollMs : false,
    retry: 1,
  });

  if (demoMode) {
    return {
      vrData: MOCK_VR,
      gates: MOCK_GATES,
      evidence: MOCK_EVIDENCE,
      prs: MOCK_PRS,
      connectionStatus: 'DISCONNECTED' as const,
      error: null,
      rateLimitReset: null,
      isLoading: false,
      contractError: null,
      parseFailures: 0,
      refetch: () => {},
    };
  }

  const anyError = vrQuery.error || runsQuery.error || prsQuery.error || contractQuery.error;
  let connectionStatus: AXLState['connectionStatus'] = 'DISCONNECTED';
  const rateLimitReset: number | null = storedRateLimitReset;

  // Parse rate limit from any error
  if (anyError) {
    const msg = (anyError as Error).message || '';
    if (msg.startsWith('RATE_LIMITED:')) {
      const reset = parseInt(msg.split(':')[1]) || null;
      if (reset && reset !== storedRateLimitReset) {
        setStoredRateLimitReset(reset);
      }
    }
  }

  // Clear rate limit once expired
  if (storedRateLimitReset && Date.now() / 1000 >= storedRateLimitReset) {
    if (storedRateLimitReset !== null) setStoredRateLimitReset(null);
  }

  // Deterministic priority: RATE_LIMITED > ERROR > POLLING > CONNECTED > DISCONNECTED
  if (!isConfigured) {
    connectionStatus = 'DISCONNECTED';
  } else if (isRateLimitedActive) {
    connectionStatus = 'RATE_LIMITED';
  } else if (anyError) {
    connectionStatus = 'ERROR';
  } else if (vrQuery.isFetching || runsQuery.isFetching) {
    connectionStatus = 'POLLING';
  } else if (vrQuery.data) {
    connectionStatus = 'CONNECTED';
  }

  // Contract missing = explicit error
  const contractError = contractQuery.error
    ? 'MISSING_CONTRACT_SSOT'
    : null;

  // Gates: from contract resolution, or fallback empty
  const gates: Gate[] = gatesQuery.data || [];

  // Evidence: from evidence.jsonl
  const evidence: EvidenceEntry[] = evidenceQuery.data?.entries || [];
  const parseFailures = evidenceQuery.data?.parseFailures || 0;

  return {
    vrData: vrQuery.data || null,
    gates,
    evidence,
    prs: prsQuery.data || [],
    connectionStatus,
    error: anyError ? (anyError as Error).message : null,
    rateLimitReset,
    isLoading: vrQuery.isLoading,
    contractError,
    parseFailures,
    refetch: () => {
      vrQuery.refetch();
      contractQuery.refetch();
      runsQuery.refetch();
      prsQuery.refetch();
      evidenceQuery.refetch();
    },
  };
}
