SYSTEM OBJECT

This folder contains the authoritative contract for PROTOCOL_13/DEGC and the unified configuration used
to compute deterministic anchors and build SYSTEM_OBJECT.json.

- PROTOCOL_13_DEGC.md  : protocol contract
- udgs.config.json     : configuration (single source of truth for paths + invariants)
