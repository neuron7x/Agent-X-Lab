"""udgs_core.ad2026 — AD-2026 ABSOLUTE_DETERMINISM_2026 integration layer."""

__all__ = [
    "identity", "typed_plan", "gates",
    "cognitive", "compliance", "runtime",
]
