import { SettingsScreen } from '@/components/axl/SettingsScreen';
export function SettingsRoute() { return <SettingsScreen />; }
