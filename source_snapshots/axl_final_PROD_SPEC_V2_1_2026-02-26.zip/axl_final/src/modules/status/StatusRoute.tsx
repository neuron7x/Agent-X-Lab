import { HomeScreen } from '@/components/axl/HomeScreen';
export function StatusRoute() { return <HomeScreen />; }
