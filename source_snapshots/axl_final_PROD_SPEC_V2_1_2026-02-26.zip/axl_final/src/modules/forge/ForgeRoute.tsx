import { ForgeScreen } from '@/components/axl/ForgeScreen';
export function ForgeRoute() { return <ForgeScreen />; }
