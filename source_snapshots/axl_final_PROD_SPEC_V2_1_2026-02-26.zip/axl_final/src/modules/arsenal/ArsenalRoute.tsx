import { ArsenalScreen } from '@/components/axl/ArsenalScreen';
export function ArsenalRoute() { return <ArsenalScreen />; }
