import { PipelineScreen } from '@/components/axl/PipelineScreen';
export function PipelineRoute() { return <PipelineScreen />; }
