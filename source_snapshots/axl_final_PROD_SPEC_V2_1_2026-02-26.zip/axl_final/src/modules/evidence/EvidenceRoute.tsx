import { EvidenceScreen } from '@/components/axl/EvidenceScreen';
export function EvidenceRoute() { return <EvidenceScreen />; }
